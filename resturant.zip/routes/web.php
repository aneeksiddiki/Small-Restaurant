<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

Auth::routes();

Route::get('/', 'HomeController@index')->name('rooturl');
Route::get('/dashboard', 'HomeController@dashboard')->name('dashboard');

Route::get('/items', 'ItemController@items')->name('items');
Route::post('/item/save', 'ItemController@saveitem')->name('saveItem');
Route::post('/item/edit', 'ItemController@edititem')->name('editItem');
Route::post('/item/delete', 'ItemController@deleteitem')->name('deleteItem');

Route::get('/makeorder', 'OrderController@makeorder')->name('makeOrder');
Route::post('/makeorder/draft', 'OrderController@makedraft')->name('makeDraft');
Route::post('/makeorder/removeitem', 'OrderController@removeitem')->name('removeItem');
Route::get('/makeorder/{invno}', 'OrderController@addorder')->name('addOrder');

Route::post('/order/confirm', 'OrderController@confirmorder')->name('confirmOrder');
Route::get('/order/confirm/list', 'OrderController@confirmlist')->name('confirmList');

Route::get('/printcopy/{invno}', 'OrderController@printcopy')->name('printCopy');


Route::get('/account', 'AccountController@account')->name('account');
Route::get('/account/{date}', 'AccountController@account')->name('accountDate');
