<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong><?php echo e(session('success')); ?></strong>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <?php if(session('failed')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong><?php echo e(session('failed')); ?></strong>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
        </div>
        <div class="col-lg-12 pb-3">
            <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-info">Back To Dashboard</a>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-3 pt-3">
            <div class="card p-3">
                <label>Select A Date</label>
                <input type="date" name="selectdate" class="form-control" id="inpDate" required>
                <button class="btn btn-primary mt-3" id="search">Search</button>
            </div>
        </div>
        <div class="col-lg-6 pt-3">
            <div class="card p-3">
                <h3>Total: <?php echo e($gtotal); ?></h3>
            </div>
        </div>
        <div class="col-lg-12 pt-3">
            <div class="card p-3 custom-shadow">
                <table id="items" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Invoice No</th>
                            <th>Date</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->invoiceno); ?></td>
                            <td><?php echo e(date("F j, Y", strtotime($item->invoicedate))); ?></td>
                            <td><?php echo e($item->gtotal); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<script>
    $(document).ready(function() {
        $('#items').DataTable();
    });

    $('#search').click(function(){
        var dt = $('#inpDate').val();
        window.location.replace('/account/'+dt);
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\class\versity project for students\resturant\resources\views/accounts.blade.php ENDPATH**/ ?>