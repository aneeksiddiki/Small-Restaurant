<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12 p-3 text-center">
            <h3 class="animate__animated animate__bounce">Welcome <?php echo e(Auth()->user()->name); ?>, What Do You Want To Do</h3>
        </div>
        <div class="col-md-6 pt-2">
            <a href="<?php echo e(route('items')); ?>">
            <div class="card p-2 animate__animated animate__bounceIn" style="background: rgb(12, 12, 46)">
                <div class="card-body text-center text-white">
                    <h2>Item Management</h2>
                    <br>
                    <i class="fas fa-pizza-slice" style="font-size: 3.5rem"></i>
                </div>
            </div>
            </a>
        </div>
        <div class="col-md-3 pt-2">
            <a href="<?php echo e(route('makeOrder')); ?>">
            <div class="card p-2 animate__animated animate__bounceIn" style="background: rgb(12, 12, 46)">
                <div class="card-body text-center text-white">
                    <h2>Make Order</h2>
                    <br>
                    <i class="fas fa-utensils" style="font-size: 3.5rem"></i>
                </div>
            </div>
            </a>
        </div>
        <div class="col-md-3 pt-2">
            <a href="<?php echo e(route('confirmList')); ?>">
            <div class="card p-2 animate__animated animate__bounceIn" style="background: rgb(12, 12, 46)">
                <div class="card-body text-center text-white">
                    <h4>Confirmed Order</h4>
                    <br>
                    <i class="fas fa-utensils" style="font-size: 3.5rem"></i>
                </div>
            </div>
            </a>
        </div>
        <div class="col-md-3 pt-2">
            <a href="<?php echo e(route('account')); ?>">
            <div class="card p-2 animate__animated animate__bounceIn" style="background: rgb(12, 12, 46)">
                <div class="card-body text-center text-white">
                    <h2>Accounts</h2>
                    <br>
                    <i class="fas fa-file-invoice-dollar" style="font-size: 3.5rem"></i>
                </div>
            </div>
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\class\versity project for students\resturant\resources\views/dashboard.blade.php ENDPATH**/ ?>